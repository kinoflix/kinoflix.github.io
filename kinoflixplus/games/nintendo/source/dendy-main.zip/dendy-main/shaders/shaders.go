package shaders

import (
	_ "embed"
)

//go:embed scanline.fs
var ScanlineFragment string
