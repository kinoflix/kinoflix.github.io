pub fn bool_to_u8(v: bool) -> u8 {
    if v { 1 } else { 0 }
}