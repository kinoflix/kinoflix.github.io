pub type Data = u8;
pub type Addr = u16;
pub type Word = u16;