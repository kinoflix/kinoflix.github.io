
let mappers = [];

// the mapper files will add to this array
