TypeNESs
=============
TypeNESs is an NES emulator in TypeScript

System Support
----------------
Visual Studio 2015 for TypeScript

No sound in IE due to HTML5 Audio support. For full media experience, please load the application in Chrome.
